package school.sptech.refuge.exception;

public class StatusInvalidoExeption extends RuntimeException {

    public StatusInvalidoExeption() {
    }
    public StatusInvalidoExeption(String message) {
        super(message);
    }
}
