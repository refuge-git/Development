package school.sptech.refuge.dto.funcionario;

import io.swagger.v3.oas.annotations.media.Schema;

public class FuncionarioTokenDto {

    private Integer userId;
    @Schema(description = "Nome completo do funcionário", example = "Marcio Santa da Silva")
    private String nome;
    @Schema(description = "Email do funcionário", example = "marcio@gmail.com")
    private String email;
    @Schema(description = "Token de acesso do funcionário", example = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkpvaG4gRG9lIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c")
    private String token;

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }
}
