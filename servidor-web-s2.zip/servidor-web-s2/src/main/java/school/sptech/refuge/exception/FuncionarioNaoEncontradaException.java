package school.sptech.refuge.exception;

public class FuncionarioNaoEncontradaException extends RuntimeException {

    public FuncionarioNaoEncontradaException(String message) {
        super(message);
    }
}
