package school.sptech.refuge.exception;

public class BeneficiarioNaoEncontradaException extends RuntimeException {
    public BeneficiarioNaoEncontradaException(String message) {
        super(message);
    }
}
