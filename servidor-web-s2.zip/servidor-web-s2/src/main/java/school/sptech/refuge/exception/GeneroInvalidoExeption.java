package school.sptech.refuge.exception;

public class GeneroInvalidoExeption extends RuntimeException {
    public GeneroInvalidoExeption(String message) {
        super(message);
    }
}
