package school.sptech.refuge.exception;

public class RacaInvalidaException extends RuntimeException {
    public RacaInvalidaException(String message) {
        super(message);
    }
}
