package school.sptech.refuge.exception;

public class TipoGeneroNaoEncontradoException extends RuntimeException {
    public TipoGeneroNaoEncontradoException(String message) {
        super(message);
    }
}
