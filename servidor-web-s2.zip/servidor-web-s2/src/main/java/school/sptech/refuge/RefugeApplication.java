package school.sptech.refuge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RefugeApplication {

	public static void main(String[] args) {
		SpringApplication.run(RefugeApplication.class, args);
	}
}
