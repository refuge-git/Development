package school.sptech.refuge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RefugeApplicationTests {

	@Test
	void contextLoads() {
	}

}
